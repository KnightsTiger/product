
public interface numberOfOrders {
	double avgOprativeTime = 7.5;

	public void viewNoOfOrders();

	public double getNumberOfResources();
}
