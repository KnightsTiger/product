import java.util.Calendar;
import java.util.Date;

public class capacityPlanning implements complitionDate, numberOfOrders, projects {

	int prodcuctionPlan = 1; // Conducting production plan for a week. If that is a month, then the variable is set to 4
	Date currentWOrkingdate;
	int numberofOrders;
	

	@Override
	public void viewNoOfOrders() {
		// Developing a viewofOrders to have a view the orders
		ProductionPlanningActivity activity = new ProductionPlanningActivity();
		

	}

	@Override
	public void scheduleApplicationDate() {
		// TODO Auto-generated method stub
		Date date= new Date();
		if (date.before(Calendar.getInstance().getTime())) {
			currentWOrkingdate = Calendar.getInstance().getTime();;
		}
		
	}

	@Override
	public void viewComplitionDate() {
		// Sales data required.
		// Temporary data is added to test the component

		double salesdata = 100.25;
		getproductiondate(); // this method gets the capacity plan

	}

	private void getproductiondate() {
		// TODO Auto-generated method stub
		Date d = new Date();
		d.getDay();
		int date = (int) startdate();

		d.setDate(date);

	}

	private Object startdate() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getNumberOfResources() {
		// TODO Auto-generated method stub
		return 0;
	}

	public boolean createRejectionNotice() {
		return false;
	}

	protected void getResponse() {
		// UI should call to this instance and get the sting value . Then set into the
		// UI
		System.out.println(" THis is a sample response");

	}

	@Override
	public void allocateProjects() {
		// TODO Auto-generated method stub
		
	}
}
