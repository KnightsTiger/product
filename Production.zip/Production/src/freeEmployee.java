
public interface freeEmployee {
	public void viewFreeEmployees();
	
}
