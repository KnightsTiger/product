
public class productionOperative {

	int fullTimeOperatives = 2;
	int contractors =  3;
	
}
