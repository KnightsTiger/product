import java.util.Scanner;

public class ProductionPlanningActivity {
	public static void main(String args[]) {
		System.out.println("Enter Number of orders for this month");
		Scanner monthPlanning = new Scanner(System.in);
		int monthlyorders = monthPlanning.nextInt();
		System.out.println("Enter Number of orders for Week 1");
		Scanner w1Planning = new Scanner(System.in);
		int w1orders = monthPlanning.nextInt();
		System.out.println("Enter Number of orders for Week 2");
		Scanner w2Planning = new Scanner(System.in);
		int w2orders = monthPlanning.nextInt();
		System.out.println("Enter Number of orders for Week 3");
		Scanner w3Planning = new Scanner(System.in);
		int w3orders = monthPlanning.nextInt();
		/*
		 * System.out.println("Enter Number of orders for Week 4"); Scanner w4Planning =
		 * new Scanner(System.in); int w4orders = monthPlanning.nextInt();
		 */
		int w4orders ;
		int totalOrders = w1orders + w2orders + w3orders;
		if (monthlyorders >= totalOrders) {
			w4orders = monthlyorders - totalOrders;
			System.out.println("We are planning to produce "+w4orders+" orders in week 4");
		} else {
			System.out.println(
					"Sorry we are unable to plan with the given weekly shedule. Please provide an alternative schedule");
		}
	}

}
