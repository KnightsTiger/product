
public interface projects {
public void allocateProjects();
}
